AOS.init({
    duration: 1000,
    offset: 120,
    easing: 'ease-in-out'
})